#ifndef STATE_LC_H
#define STATE_LC_H



/**************************************************************************/
//    Inclusion of the necessary libraries
/**************************************************************************/

#include <Arduino.h>
#include "projectconfig.h"



/**************************************************************************/
//    Functions
/**************************************************************************/

void State_LC(int Kph);
/*
    @brief      Explication
    @param[in]  Parametres
    @return     Return
*/



#endif
